# BackupForce Portable

## Quick Start
Double-click: **BackupForce.vbs**

## Requirements
Java 11 or higher must be installed on your computer.
Download from: https://adoptium.net/

## Files
- BackupForce.jar - Main application
- BackupForce.vbs - Launcher (recommended - no console)
- BackupForce.bat - Launcher (alternative - shows console)

## Support
Developed by Victor Felisbino
